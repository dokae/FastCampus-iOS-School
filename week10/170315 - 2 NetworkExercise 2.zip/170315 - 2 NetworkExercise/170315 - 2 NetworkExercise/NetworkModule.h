//
//  NetworkModule.h
//  170315 - 2 NetworkExercise
//
//  Created by Park Jae Han on 2017. 3. 17..
//  Copyright © 2017년 Park Jae Han. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NetworkModule : NSObject

- (void)initWithSignInID:(NSString *)userID userPW:(NSString *)userPW;
- (void)initWithSignOut;
- (void)initWithSignUpID:(NSString *)userID userPW:(NSString *)userPW userVPW:(NSString *)userVPW;


@end
