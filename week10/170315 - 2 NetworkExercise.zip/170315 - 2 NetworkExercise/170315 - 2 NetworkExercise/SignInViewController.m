//
//  SignInViewController.m
//  170315 - 2 NetworkExercise
//
//  Created by Park Jae Han on 2017. 3. 15..
//  Copyright © 2017년 Park Jae Han. All rights reserved.
//

#import "SignInViewController.h"
#import "DataCenter.h"

@interface SignInViewController ()
<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *idField;
@property (weak, nonatomic) IBOutlet UITextField *pwField;

@end

@implementation SignInViewController

/*
 
 로그인------
 id입력
 pw입력
 리턴키 or 버튼 누름
 id,pw 확인
 맞으면 로그인
 틀리면 팝업
 
 */


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (textField.tag == 100) {
        
        [self.pwField becomeFirstResponder];
    } else {
        
        [self.pwField resignFirstResponder];
        [self checkUserAccount];
    }

    return YES;
}


- (IBAction)didSelectedBtn:(UIButton *)sender {
    
    if (sender.tag == 10) {
        
        [self checkUserAccount];
    
    } else if (sender.tag == 30) {
    
        [self apiLogout];
    } else if (sender.tag == 40) {
        
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}


- (void)checkUserAccount {
    
    [self apiLogin];
}


- (void)apiLogin {
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURL *url = [NSURL URLWithString:LOGIN_URL];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSString *userID = self.idField.text;
    NSString *userPW = self.pwField.text;
    
    NSLog(@"%@, %@", self.idField.text, self.pwField.text);
    
    NSString *noteDataString = [NSString stringWithFormat:@"username=%@&password=%@", userID, userPW];
    request.HTTPBody = [noteDataString dataUsingEncoding:NSUTF8StringEncoding];
    request.HTTPMethod = @"POST";
    
    NSURLSessionUploadTask *postDataTask = [session uploadTaskWithRequest:request fromData:nil completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary *responsData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
        
        if (error != nil) {

            NSLog(@"시스템에러");

        } else {
            
            if (statusCode == 200) {
                
                [[DataCenter sharedInstance] saveUserToken:[responsData objectForKey:@"key"]];
                
                NSLog(@"token:::: %@",[responsData objectForKey:@"key"]);
                NSLog(@"data:::: %@", responsData);
                [self okAlert];

            } else {
                
                NSLog(@"다시입력");
            }
            
        }
    }];
    
    [postDataTask resume];
    
}


- (void)apiLogout {
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURL *url = [NSURL URLWithString:LOGOUT_URL];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSString *noteDataString = [NSString stringWithFormat:@"Authorization=Token %@", [DataCenter sharedInstance].userToken];
    request.HTTPBody = [noteDataString dataUsingEncoding:NSUTF8StringEncoding];
    request.HTTPMethod = @"POST";
    
    NSURLSessionUploadTask *postDataTask = [session uploadTaskWithRequest:request fromData:nil completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        
        
        NSDictionary *responsData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        NSLog(@"data ::::::::: %@", responsData);
        [self logoutAlert];
        
    }];
    
    [postDataTask resume];
    
}


- (void)okAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"로긴성공" message:@"성공" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (void)logoutAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"로그아웃" message:@"성공" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (void)noAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"다시확인" message:@"다시쳐" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self.idField becomeFirstResponder];
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.idField becomeFirstResponder];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
