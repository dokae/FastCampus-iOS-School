//
//  SignUpViewController.m
//  170315 - 2 NetworkExercise
//
//  Created by Park Jae Han on 2017. 3. 15..
//  Copyright © 2017년 Park Jae Han. All rights reserved.
//

#import "SignUpViewController.h"
#import "DataCenter.h"
#import "MainViewController.h"

@interface SignUpViewController ()
<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *idField;
@property (weak, nonatomic) IBOutlet UITextField *pwField;
@property (weak, nonatomic) IBOutlet UITextField *verifyPwField;

@end

@implementation SignUpViewController


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if (textField.tag == 1000) {
        
        [self.pwField becomeFirstResponder];
        
    } else if (textField.tag == 2000) {
        
        [self.verifyPwField becomeFirstResponder];
        
    } else if (textField.tag == 3000) {
        
        [self.verifyPwField resignFirstResponder];
        
        if (self.pwField.text != self.verifyPwField.text) {
            
            [self noAlert];
        } else {
            
            [self signUpUserAccount];
        }
    }

    return YES;
}


- (void)signUpUserAccount {
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURL *url = [NSURL URLWithString:SIGNUP_URL];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    NSString *userID = self.idField.text;
    NSString *userPW = self.pwField.text;
    NSString *userVPW = self.verifyPwField.text;
    
    NSLog(@"%@, %@, %@", self.idField.text, self.pwField.text, self.verifyPwField.text);
    
    NSString *noteDataString = [NSString stringWithFormat:@"username=%@&password1=%@&password2=%@", userID, userPW, userVPW];
    request.HTTPBody = [noteDataString dataUsingEncoding:NSUTF8StringEncoding];
    request.HTTPMethod = @"POST";
    
    NSURLSessionUploadTask *postDataTask = [session uploadTaskWithRequest:request fromData:nil completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary *responsData = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        
        NSString *userToken = [responsData objectForKey:@"key"];
        [DataCenter sharedInstance].userToken = userToken;
        NSLog(@"token ::::::::: %@", userToken);
        
        [self okAlert];
        
    }];
    
    [postDataTask resume];
    
}

- (void)okAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"가입완료" message:@"가입완료됨" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}


- (void)noAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"비번확인" message:@"동일한 비번입력" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self.verifyPwField becomeFirstResponder];
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}

- (void)emptyAlert {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"입력하시오" message:@"입력하시오" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [self.verifyPwField becomeFirstResponder];
    }];
    
    [alertController addAction:okAction];
    [self presentViewController:alertController animated:YES completion:nil];
}



- (IBAction)didSelectedBtn:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
