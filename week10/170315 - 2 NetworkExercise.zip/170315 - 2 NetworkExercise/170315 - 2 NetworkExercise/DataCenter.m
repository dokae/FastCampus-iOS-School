//
//  DataCenter.m
//  170315 - 2 NetworkExercise
//
//  Created by Park Jae Han on 2017. 3. 15..
//  Copyright © 2017년 Park Jae Han. All rights reserved.
//

#import "DataCenter.h"

@implementation DataCenter


+ (instancetype)sharedInstance {
    
    static DataCenter *dataCenter = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        dataCenter = [[DataCenter alloc] init];
    });
    
    return dataCenter;
}


- (instancetype)init {
    
    self = [super init];
    if (self) {
        
        [self loadUserToken];
    }
    return self;
}


- (void)loadUserToken {
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:USER_TOKEN] != nil) {
        
        self.userToken = [[NSUserDefaults standardUserDefaults] objectForKey:USER_TOKEN];
    }
}


- (void)saveUserToken:(NSString *)token {
    
    self.userToken = token;
    [[NSUserDefaults standardUserDefaults] setObject:self.userToken forKey:USER_TOKEN];
}


@end
